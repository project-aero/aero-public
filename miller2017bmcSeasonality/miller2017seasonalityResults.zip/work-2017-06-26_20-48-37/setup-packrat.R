#!/usr/bin/env Rscript

hostname <- Sys.getenv("HOSTNAME")
if (grepl("olympus.psc.edu", hostname)){
  .libPaths("~/R/x86_64-pc-linux-gnu-library/3.3") ## To use updated versions
}

packrat::init(enter = FALSE)
