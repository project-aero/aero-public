#!/usr/bin/env Rscript

## Setup -----
source("sim-study-functions.R")
packrat_setup()
## Small scale is useful for debugging
is_small_scale <- Sys.getenv("is_small_scale") == "TRUE"
cluster <- parallel_setup(is_small = is_small_scale)

## Load required data -----

simulated_procs <- readRDS("simulated-procs-tuning.rds")

## Aggregate cases over reporting periods -----

simulated_observations <- get_obs(simulated_procs)

## Create design for analysis -----

levs <- list()
levs$bandwidth <- 100
levs$lag <- 1
levs$preprocessing <- "none"
levs$kernel <- NA
levs$filter_l <- seq(5, 105, by = 25)
levs$filter_h <- seq(40, 215, by = 25)
analysis_des_mat <- do.call(expand.grid, c(levs, stringsAsFactors = FALSE))
test <- analysis_des_mat$filter_l < analysis_des_mat$filter_h
analysis_des_mat <- analysis_des_mat[test, ]

## Run and save analysis -----

analyzed_observations <- calc_ews(sim_obs = simulated_observations,
                                  des = analysis_des_mat,
                                  ews_cor = get_filter_ews)
parallel::stopCluster(cluster)

saveRDS(simulated_observations, "simulated-observations-tuning.rds")
saveRDS(analysis_des_mat, "analysis-des-mat-tuning.rds")
saveRDS(analyzed_observations, "analyzed-observations-tuning.rds")
