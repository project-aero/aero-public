#!/usr/bin/env Rscript

source("sim-study-functions.R")

## Load required data -----

process_des_mat <- readRDS("process-des-mat-tuning.rds")
analysis_des_mat <- readRDS("analysis-des-mat-tuning.rds")
analyzed_observations <- readRDS("analyzed-observations-tuning.rds")

## Summarize and save summary -----

res <- extract_aucs(pdm = process_des_mat, adm = analysis_des_mat,
                    aobs = analyzed_observations)

saveRDS(res, "res-tuning.rds")
