#!/usr/bin/env Rscript

source("sim-study-functions.R")

## Load required data -----

process_des_mat <- readRDS("process-des-mat.rds")
analysis_des_mat <- readRDS("analysis-des-mat.rds")
analyzed_observations <- readRDS("analyzed-observations.rds")

## Summarize and save summary -----

res <- extract_aucs(pdm = process_des_mat, adm = analysis_des_mat,
                    aobs = analyzed_observations)

saveRDS(res, "res.rds")
