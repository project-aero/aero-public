#!/usr/bin/env bash
#PBS -N simseasonal
#PBS -l nodes=1:ppn=56
#PBS -l walltime=96:00:00

set -e
if [[ "$HOSTNAME" =~ "olympus.psc.edu" ]]; then {
  module load r/3.3.1
  module load pandoc
  srcdir=${srcdir:-$PBS_O_WORKDIR}
}
else
  srcdir=${srcdir:-$PWD}
fi

tstamp=$(date +%Y-%m-%d_%H-%M-%S)
tsdir="work-${tstamp}"
wkdir=${wkdir:-$tsdir}

cd ${srcdir}
if [ ! -d "$wkdir" ]; then
  mkdir $wkdir
  cp *.R *.Rmd Makefile .Rprofile *.sty $wkdir
  cd $wkdir
  ln -s ../packrat .
else
  cd $wkdir
fi
make $make_target
