#!/usr/bin/env Rscript

## Setup -----
source("sim-study-functions.R")
packrat_setup()
## Small scale is useful for debugging
is_small_scale <- Sys.getenv("is_small_scale") == "TRUE"
cluster <- parallel_setup(is_small = is_small_scale)

## Create design for process model simulations -----
levs <- list()
levs$beta_mean_init <- 0.04
levs$frac_mindev <- seq(0, 1, length.out=3)
levs$seasonal_forcing_type <- "sine"
levs$t_start <- 20 * 365
levs$external_forcing <- 12 / 365
levs$host_lifetime <- 70 * 365
levs$infectious_days <- 14
levs$observation_days <- 25 * 365
levs$population_size <- 2e5
levs$process_reps <- 100
if (is_small_scale){
  levs$population_size <- 1e2
  levs$process_reps <- 10
  levs$frac_mindev <- c(0, 1)
}
process_des_mat <- do.call(expand.grid, c(levs, list(stringsAsFactors = FALSE)))

## Do and save simulations -----

simulated_procs <- do_sims(process_des_mat)
parallel::stopCluster(cluster)

saveRDS(process_des_mat, "process-des-mat-tuning.rds")
saveRDS(simulated_procs, "simulated-procs-tuning.rds")
