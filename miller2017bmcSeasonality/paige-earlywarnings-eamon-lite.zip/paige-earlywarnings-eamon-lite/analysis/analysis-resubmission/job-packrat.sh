#!/bin/bash

#PBS -N sim-test
#PBS -l nodes=1:ppn=2
#PBS -l walltime=03:00:00

module load r/3.3.1

cd ${HOME}/src/paige-earlywarnings/analysis/analysis-resubmission

./setup-packrat.R
