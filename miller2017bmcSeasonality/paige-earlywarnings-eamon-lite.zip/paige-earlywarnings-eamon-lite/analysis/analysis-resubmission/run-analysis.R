#!/usr/bin/env Rscript

## Setup -----
source("sim-study-functions.R")
packrat_setup()
## Small scale is useful for debugging
is_small_scale <- Sys.getenv("is_small_scale") == "TRUE"
cluster <- parallel_setup(is_small = is_small_scale)

## Load required data -----

simulated_procs <- readRDS("simulated-procs.rds")

## Aggregate cases over reporting periods -----

simulated_observations <- get_obs(simulated_procs)

## Create design for analysis -----

levs <- list()
levs$bandwidth <- c(100, 150)
levs$lag <- c(1)
levs$preprocessing <- c("none", "diff", "stl")
levs$filter_l <- 55
levs$filter_h <- 115
levs$kernel <- c("uniform", "gaussian")
if (is_small_scale){
  levs$bandwidth <- 100
}
analysis_des_mat <- do.call(expand.grid, c(levs, stringsAsFactors = FALSE))

## Run and save analysis -----

analyzed_observations <- calc_ews(sim_obs = simulated_observations,
                                  des = analysis_des_mat, ews_cor = get_ews_cor)
parallel::stopCluster(cluster)

saveRDS(simulated_observations, "simulated-observations.rds")
saveRDS(analysis_des_mat, "analysis-des-mat.rds")
saveRDS(analyzed_observations, "analyzed-observations.rds")
