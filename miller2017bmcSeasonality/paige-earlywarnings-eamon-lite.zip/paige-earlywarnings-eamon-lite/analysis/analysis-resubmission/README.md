
## How to reproduce the figures and simulation results

The results were generated with R 3.3.1 running on single node of the
Olympus cluster of the Pittsburgh Supercomputing Center. It should be
possible to reproduce the results with the same version of R on
another Linux system. In fact, slightly different versions of R and
different operating systems may work but, as the saying goes, your
mileage may vary.

The R package versions used have been recorded in the file
packrat/packrat-lock. Therefore, if the R packrat package is
installed, the required version of all packages should be downloaded
and installed to a packrat library when any of the R scripts are run
that contain a line reading "packrat::restore()".

GNU Make can be used to reproduce the full analysis. To run all of the
code, start a terminal and change into the directory containing this
README.md and the associated makefile and R scripts. Then execute

     make

Even if you do not want to reproduce all of the results using make,
the makefile can be used to learn the sequence of commands used to
generate a particular result. Also, the makefile indicates which files
are needed to reproduce the results. If a file is a prerequisite for a
rule needed to create the all target in the makefile, then it is needed
to reproduce the results. Some other files have been included because
they may be useful in some other way.

Generation of a PDF from the RMD file requires that pandoc (version >=
1.12.3) and Latex are installed on the system as well as the Tex
package titling. The figures should be reproducible without these by
tangling the R code and running those scripts in R.
