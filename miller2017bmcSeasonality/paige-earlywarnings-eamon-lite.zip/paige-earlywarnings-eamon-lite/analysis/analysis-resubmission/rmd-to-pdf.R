#!/usr/bin/env Rscript

source("sim-study-functions.R")
packrat_setup()
rmarkdown::render("seasonal-ews.Rmd")
