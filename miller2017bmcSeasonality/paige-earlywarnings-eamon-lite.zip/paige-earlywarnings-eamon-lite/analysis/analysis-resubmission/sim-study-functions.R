packrat_setup <- function(){
  if (file.exists(".Rprofile")){
    source(".Rprofile") # Necessary on Olympus to correct .libPaths()
    packrat::restore()
  } else {
    warning("No .Rprofile found. Not using packrat to get tested package versions")
  }
}

parallel_setup <- function(is_small, seed = 1){
### Due to the large size results of parallelized jobs, the SNOW-style
### cluster backend seems better than multicore approach to
### parallelization. With the cluster approach, we can fork before any
### results are computed to create workers rather than over time as
### results are generated. The forked processes share memory with the
### parent. So as the results accumulate and the parent's memory use
### grows, the memory allocated to each forked process also
### grows. Even though the forked processes don't need to modify the
### results, and thus the memory actually used by them is not great,
### the allocation seems to trigger some mechanism that kills jobs on
### the Olympus cluster. It could be the Linux OOM killer.
  require(foreach)
  if (is_small) {
    clust <- parallel::makeForkCluster(nnodes = 2, outfile = "cluster-outfile")
    doParallel::registerDoParallel(cl = clust, outfile = "cluster-outfile")
  } else {
    clust <- parallel::makeForkCluster(nnodes = 56)
    doParallel::registerDoParallel(cl = clust)
  }
  parallel::clusterSetRNGStream(cl = clust, iseed = seed)
  clust
}

simulate_process <- function(beta_mean_init, frac_mindev,
                             seasonal_forcing_type = c("sine", "termtime",
                                 "metcalf", "square"), t_start, host_lifetime,
                             infectious_days, observation_days, population_size,
                             process_reps, external_forcing,
                             is_eta_seasonal = FALSE){

  times <- seq(1, observation_days)
  params <- c(gamma = 1 / infectious_days, mu = 1 / host_lifetime,
              d = 1 / host_lifetime, eta = external_forcing / population_size,
              beta = beta_mean_init, rho = 0.1, S_0 = 1, I_0 = 0, R_0 = 0,
              N_0 = population_size)

  # Calculating increasing mean beta
  beta_final <- params["gamma"] + params["mu"]
  beta_0 <- rep(params['beta'],times = t_start)
  beta_inc <- seq(params['beta'], beta_final,
                  length = (observation_days - t_start))
   ## Since covariate summed with param vector in simulator
  beta_full <- c(beta_0, beta_inc) - params['beta']

  period <- 365 # Period of seasonality
  min_scale <- function(x, mindev) {
    ## Centers x on zero and then scales so minimum deviation matches mindev
    ret <- x - mean(x)
    scale <- min(ret) / mindev
    ret / scale
  }
  get_sine_devs <- function(times, period = 365, ...) {
    ret <- sinpi(2 * times / period)
    min_scale(ret, ...)
  }
  get_term_time_devs <- function(times, period = 365, ...) {
    stopifnot(period == 365)
    value_rle <- structure(list(lengths = c(6L, 93L, 16L, 84L, 51L, 49L, 8L,
                                            48L, 10L),
                                values = c(-1L, 1L, -1L, 1L, -1L, 1L, -1L,
                                           1L, -1L)),
                           .Names = c("lengths", "values"), class = "rle")
    value <- inverse.rle(value_rle)
    min_scale(value, ...)
  }
  get_metcalf_devs <- function(times, period = 365, ...){
    stopifnot(period == 365)
    monthAve <- structure(list(V1 = 1:12,
                               V2 = c(8.238508495, 8.306464661, 8.083180113,
                                      8.112451276, 7.791939398, 6.151430463,
                                      6.491064205, 8.442524086, 9.733691255,
                                      9.879311613, 8.685371773, 10.50077223)),
                            .Names = c("V1", "V2"), class = "data.frame",
                            row.names = c(NA, -12L))
    daysInMonths <- c(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    dayAve <- as.numeric(rep(monthAve[,2], times = daysInMonths))
    min_scale(dayAve, ...)
  }
  get_square_devs <- function(times, period = 365, ...){
    ret <- rep(1, times = period)
    ret[1:floor(period / 2)] <- -1
    min_scale(ret, ...)
  }
  seasonal_forcing_type <- match.arg(seasonal_forcing_type)
  seasonal_devs <- switch(seasonal_forcing_type,
                          sine = get_sine_devs(times, mindev = -params['beta']),
                          termtime = get_term_time_devs(times, mindev = -params['beta']),
                          metcalf = get_metcalf_devs(times, mindev = -params['beta']),
                          square = get_square_devs(times, mindev = -params['beta']))
  beta_amp <- beta_full + frac_mindev * seasonal_devs
  if (is_eta_seasonal) {
    seasonal_devs <- switch(seasonal_forcing_type,
                            sine = get_sine_devs(times, mindev = -params['eta']),
                            termtime = get_term_time_devs(times, mindev = -params['eta']),
                            metcalf = get_metcalf_devs(times, mindev = -params['eta']),
                            square = get_square_devs(times, mindev = -params['eta']))
    eta_amp <- frac_mindev * seasonal_devs
  } else {
    eta_amp <- rep(0, times = observation_days)
  }
  tol <- sqrt(.Machine$double.eps)
  eta_amp <- eta_amp + tol
  beta_amp <- beta_amp + tol
  stopifnot(isTRUE(all(beta_amp + params["beta"] >= 0)))
  stopifnot(isTRUE(all(eta_amp + params["eta"] >= 0)))

  #variables for changing parameter values in test interval
  covtest <- data.frame(gamma_t = rep(0, times = observation_days),
                        mu_t = rep(0, times = observation_days),
                        d_t = rep(0, times = observation_days),
                        eta_t = eta_amp, beta_t = beta_amp, time = times)

  sim <- spaero::create_simulator(times = times, params = params, covar = covtest,
                                  transmission = "frequency-dependent")

  ret <- list()
  do_sim <- function(obj, nsim = process_reps){
    cols_to_delete <- c("reports", "gamma_t", "mu_t", "d_t")
    ret <- pomp::simulate(obj, nsim = nsim, as.data.frame = TRUE)
    ret$Rnot <- ((params['beta'] + ret$beta_t) /
                 (params['gamma'] + ret$gamma_t + params['d'] + ret$d_t))
    ret[, !colnames(ret) %in% cols_to_delete]
  }

  full <- do_sim(sim)
  is_null_beta <- (full$time > 3649) & (full$time < t_start)
  is_test_beta <- (full$time > t_start)
  ret$test <- full[is_test_beta, ]
  ret$null <- full[is_null_beta, ]
  ret
}

do_sims <- function(des) {
  options <- list(preschedule = FALSE) # To keep results <2GB limit
  foreach(i = seq(1, nrow(des)),
          .options.snow = options) %dopar%
      do.call(simulate_process, des[i, ])
}

sample_observation <- function(procs){
  aggregation_days <- 7
  splt <- function(x) {
    splits <- split(x$cases, x$sim)
    lapply(splits, aggregate.ts,
           nfrequency=1 / aggregation_days)
  }
  lapply(procs, splt)
}

get_obs <- function(sim_procs){
  options <- list(preschedule = FALSE) # To keep results <2GB limit
  spit <- iterators::iter(sim_procs)
  foreach (sp = spit, .options.snow = options) %dopar%
      sample_observation(procs = sp)
}

wavelet_filter <- function (y1, x1 = seq_along(y1), h, l){ #
  t1 <- data.frame(time=x1, incid=y1)

  ## Continuous bias corrected wavelet transform (liu et al 2007)
  wt.t1 <- biwavelet::wt(t1, do.sig=FALSE)
  h=max(which(wt.t1$scale<h))
  l=min(which(wt.t1$scale>l))
  if (!all(is.finite(c(h, l)))) {
      warning(paste("Selected wavelet bands are outside of range of computed scales.",
                    "Power is always zero by definition."))
      return(rep(0, nrow(t1)))
  }
  Power=wt.t1$power.corr[l:h, , drop = FALSE]
  stat <- apply(X=Power, FUN=sum, MARGIN=2)
  return(stat)
}

wavelet_median <- function (y1, x1 = seq_along(y1)){
  t1 <- data.frame(time=x1, incid=y1)

  ## Continuous bias corrected wavelet transform (liu et al 2007)
  wt.t1 <- biwavelet::wt(t1, do.sig=FALSE)

  Power=wt.t1$power.corr
  probfun <- function(x) cumsum(x) / sum(x)
  ppower <- apply(Power, 2, probfun)
  islower50 <- ppower < 0.5
  get_med_ind <- function(x) match(FALSE, x)
  inds <- apply(islower50, 2, get_med_ind)
  median <- wt.t1$scale[inds]
  median
}

calc_auc <- function(predictions, is_null){
  test <- !is.na(predictions)
  predictions <- predictions[test]
  is_null <- is_null[test]
  r <- rank(predictions)
  r1 <- sum(r[!is_null])
  n1 <- sum(!is_null)
  n2 <- sum(is_null)
  (r1 - n1 * (n1 + 1) / 2) / (n1 * n2)
}

get_ews_cor <- function(reports, bw, lg, preproc, filter_l, filter_h, kernel){
  stl_preproc <- function(x) {
    x <- ts(x, frequency = 52)
    tser <- stl(x, s.window = "periodic")$time.series
    list(rep = tser[, "remainder"], center = tser[, "trend"])
  }
  preproc_reports <- switch(preproc,
                            none = list(rep = reports, center = NA),
                            diff = list(rep = diff(reports, lag = 52),
                                center = NA),
                            stl = stl_preproc(reports))
  if (preproc == "stl") {
    center_trend <- "assume_zero"
  } else {
    center_trend <- "local_constant"
  }
  out <- spaero::get_stats(preproc_reports$rep,
                           center_bandwidth = bw, stat_bandwidth = bw,
                           center_trend = center_trend,
                           stat_trend = "local_constant",
                           center_kernel = kernel,
                           stat_kernel = kernel, lag = lg)
  if (preproc == "stl") {
    out$stats$mean <- preproc_reports$center
    out$stats$index_of_dispersion <- out$stats$variance / out$stats$mean
    out$stats$coefficient_of_variation <- sqrt(out$stats$variance) /
      out$stats$mean
    mstats_nms <- c("mean", "index_of_dispersion", "coefficient_of_variation")
    mstats <- out$stats[mstats_nms]
    mtaus <- lapply(mstats, get_tau, time = seq_along(preproc_reports$rep))
    out$taus[mstats_nms] <- mtaus
  }
  wstats <- list()
  wstats$wavelet_filt <- wavelet_filter(reports, h = filter_h, l = filter_l)
  wstats$wavelet_med <- wavelet_median(reports) # Median spectral period
  wtaus <- lapply(wstats, get_tau, time = seq_along(reports))
  list(stats = c(out$stats, wstats), taus = unlist(c(out$taus, wtaus)))
}

get_filter_ews <- function(reports, preproc, filter_l, filter_h, ...){
  if (preproc != "none") warnings("Preprocessing does not apply to wavelet EWS")
  res <- list()
  res$stats$wavelet_filt <- wavelet_filter(reports, h = filter_h, l = filter_l)
  res$taus <- c(wavelet_filt = get_tau(res$stats$wavelet_filt, time = seq_along(reports)))
  res
}

get_tau <- function(stat_ts, time){
  stats::cor(stat_ts, time, use = "pairwise.complete.obs", method = "kendall")
}

analyze_observations <- function(bandwidth, lag, obs, filter_l, filter_h,
                                 kernel, ews_cor,
                                 preprocessing = c("none", "diff", "stl")){
  preprocessing <- match.arg(preprocessing)
  loop_manip <- function(x){
    sc <- lapply(x, ews_cor, bw = bandwidth, lg = lag, preproc = preprocessing,
                 filter_l = filter_l, filter_h = filter_h, kernel = kernel)
    taus <- lapply(sc, "[[", "taus")
    taus <- do.call(cbind, taus)
    list(sc=sc, taus=taus)
  }
  sct <- lapply(obs, loop_manip)
  is_null <- c(rep(FALSE, ncol(sct$test$taus)), rep(TRUE, ncol(sct$null$taus)))
  preds <- cbind(sct$test$taus, sct$null$taus)
  df <- data.frame(is_null, t(preds), row.names=1:ncol(preds))
  samp_stat <- function(x, w) {
    apply(x[w, -1, drop = FALSE], 2, calc_auc, is_null=df$is_null[w])
  }
  bs <- boot::boot(data=df, statistic=samp_stat, R=300)
  bssd <- apply(bs$t, 2, sd, na.rm=TRUE)
  list(sct=sct, auc=bs$t0, auc_stderr=bssd)
}

calc_ews <- function(sim_obs, des, ews_cor){
  options <- list(preschedule = FALSE) # To keep results <2GB limit
  soit <- iterators::iter(sim_obs)
  foreach (so = soit, .options.snow = options) %:%
    foreach (adm = iterators::iter(des, by = "row"),
             .options.snow = options) %dopar%
               do.call(analyze_observations,
                       c(adm, list(obs = so, ews_cor = ews_cor)))
}

extract_aucs <- function(pdm, adm, aobs){
  res <- list()
  n <- 1
  for (i in seq(1, nrow(pdm))){
    pvars <- pdm[i, ]
    for (m in seq(1, nrow(adm))){
      auc <- aobs[[i]][[m]]$auc
      names(auc) <- paste("AUC", names(auc), sep="_")
      aucse <- aobs[[i]][[m]]$auc_stderr
      names(aucse) <- paste(names(auc), "stderr", sep="_")
      avars <- adm[m, ]
      res[[n]] <- data.frame(c(pvars, avars, auc, aucse))
      n <- n + 1
    }
  }
  do.call(rbind, res)
}

colramp <-
c("#800000", "#840304", "#880508", "#8c080c", "#910a10", "#950e14",
  "#991017", "#9d131b", "#a2151e", "#a61823", "#ab1b27", "#ae1e2a",
  "#b2212e", "#b62431", "#ba2834", "#bd2b38", "#c12e3a", "#c4323e",
  "#c73640", "#cb3a43", "#ce3d46", "#d14149", "#d4464b", "#d74a4e",
  "#da4e50", "#dd5252", "#df5654", "#e25a55", "#e45e57", "#e76259",
  "#e9665a", "#eb6c5b", "#ed6f5c", "#ef745d", "#f1795e", "#f37c5e",
  "#f5815f", "#f6855f", "#f88a5f", "#f98f5f", "#fa935f", "#fc985f",
  "#fd9d5e", "#fea15d", "#ffa65d", "#ffaa5b", "#ffaf5a", "#ffb559",
  "#ffba57", "#ffbf55", "#ffc453", "#ffc851", "#ffcd4e", "#ffd14b",
  "#ffd648", "#ffda44", "#ffdf40", "#ffe33c", "#ffe937", "#ffed31",
  "#fff12a", "#fff622", "#fffa16", "#ffff00", "#fefb1e", "#fcf62e",
  "#fbf03a", "#f9ec43", "#f8e74b", "#f6e352", "#f4dd59", "#f2d95f",
  "#f1d464", "#efd06a", "#eccb6f", "#eac674", "#e8c179", "#e6bc7e",
  "#e4b882", "#e2b386", "#dfaf8b", "#dcaa8f", "#daa593", "#d7a197",
  "#d59d9a", "#d2979e", "#cf93a2", "#cc8fa5", "#c989a9", "#c685ac",
  "#c281b0", "#bf7bb3", "#bb78b6", "#b772ba", "#b36ebd", "#b06ac0",
  "#ab65c3", "#a761c5", "#a35bc8", "#9f57cb", "#9a53cd", "#954ed0",
  "#8f49d2", "#8b46d4", "#8440d6", "#7f3cd8", "#7837d9", "#7233da",
  "#6b2fdb", "#642adc", "#5d25dc", "#5521dc", "#4e1cdb", "#4618da",
  "#3d14d7", "#3510d5", "#2c0cd1", "#2408cd", "#1c05c7", "#1503c1",
  "#0d02bb", "#0701b3", "#0300ab", "#0100a3", "#00009c", "#000094",
  "#00008b")
